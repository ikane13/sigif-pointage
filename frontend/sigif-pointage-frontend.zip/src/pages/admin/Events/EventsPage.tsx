export const EventsPage = () => {
  return (
    <div>
      <h1>Événements</h1>
      <p>Liste des événements à venir...</p>
    </div>
  );
};