export const ParticipantsPage = () => {
  return (
    <div>
      <h1>Participants</h1>
      <p>Liste des participants...</p>
    </div>
  );
};