export { Loader } from './Loader';
export type { LoaderProps, LoaderVariant, LoaderSize } from './Loader.types';