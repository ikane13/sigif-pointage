export { Modal } from './Modal';
export type { ModalProps, ModalSize } from './Modal.types';