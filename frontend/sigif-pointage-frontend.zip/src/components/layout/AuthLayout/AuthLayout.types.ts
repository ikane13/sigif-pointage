import type { ReactNode } from 'react';

export interface AuthLayoutProps {
  children: ReactNode;
}